/**
 * Created by aren on 16-9-6.
 */

//    获取bg对象
    /*
    * bgwidth:1000 height：590；
    * */
var bg=document.getElementById("bg_control");
var strogLifeNode=document.getElementById("strogLife");
var scoreNumNode=document.getElementById("scoreNum");
var expNode=document.getElementById("expBg");
var boomNode=document.getElementById("boom");
var gameStartNode=document.getElementById("startGame");
var baginWarpNode=document.getElementById("baginWarp");
var min1Node=document.getElementById("min1");
var min2Node=document.getElementById("min2");
var sec1Node=document.getElementById("sec1");
var sec2Node=document.getElementById("sec2");
var skillNode=document.getElementById("skill");
var jifenbanNode=document.getElementById("jifenban");
var finalfenshu=document.getElementById("finalfenshu");
var chongwan=document.getElementById("chongwan");
var xuetiaoNode=document.getElementById("xuetiao");
var boss;
//xxxx是sec1第几次变为0；
var xxxx=1;
// 移动状态控制
var moveLeft=false;
var moveRight=false;
var moveUp=false;
var moveDown=false;
var isdazhao=false;
//是否发射子弹
var haveBullet=false;
//游戏进行中？
var gameing=true;
var Playerscore=0;
var exp=0;
var ChestCount=2;
var min1=0;
var min2=1;
var sec1=3;
var sec2=1;
var time=0;
var skilltime=10;
var bossatckTime=0;
//大招释放中
var cunzaidazhao=0;
var MyStrogMoveTime;
var attBulletTime;
var BullterMoveTime;
var BadBirdTime;
var BadBirdMoveTime;
var ChestLeaveTime;
var expGrowTime;
var changeBoomTime;
var TimeChangeTime;
var GameOverTime;
var fangdazhaoTime;
var bossMoveTime;
var bossAtckTime;
var bossBulletMoveTime;
//子弹数组
var BulletArray=new Array();
//敌机数组
var BadBirdAraay=new Array();
//宝箱数组
var ChestArray=new Array();
//boss子弹数组
var bossBulletArray=new Array();
//创建一个主角对象
function Strog(speed){
//    创建一个img节点
    this.imgNode=document.createElement("img");
    //定义位置变量
    this.posX=50;
    this.posY=300;
//    速度
    this.speed=speed;
//    主角生命
    this.life=56;
//    主角等级
    this.lv=1;
//    初始化位置
    this.initPos=function () {
        bg.appendChild(this.imgNode);
        this.imgNode.src="images/dragon/small/stand.gif";
        this.imgNode.style.left=this.posX+"px";
        this.imgNode.style.top=this.posY+"px";
    }
    //自己调用初始化位置方法
    this.initPos();

}
//创建一个子弹对象
function Bullter(imgSrc) {
    //创建bullter的节点
    this.imgNode=document.createElement("img");
//    子弹的速度
    this.speed=15;
    //    是否击中
    this.isHit=false;
    this.imgSrc=imgSrc;
//    消失时间
    this.leaveTime=5;
//    初始化子弹节点
    this.initPosBull=function () {
        bg.appendChild(this.imgNode);
        this.imgNode.src=imgSrc;
    }
    this.initPosBull();
//    子弹自动移动
    this.BullterMove=function () {
        this.imgNode.style.left=parseInt(this.imgNode.style.left)+this.speed+"px";
    }
}
//控制主角移动函数
function myStrogMove() {
//    上
    if(moveUp){
        /*if(!haveBullet) {
            myStrog.imgNode.src = "images/dragon/small/move.gif";
        }*/
        myStrog.imgNode.style.top=parseInt(myStrog.imgNode.style.top)-myStrog.speed+"px";
        if (parseInt(myStrog.imgNode.style.top)<=0){
            myStrog.imgNode.style.top="0px";
        }
    }
//    下
    if(moveDown){
       /* if(!haveBullet) {
            myStrog.imgNode.src = "images/dragon/small/move.gif";
        }*/
        myStrog.imgNode.style.top=parseInt(myStrog.imgNode.style.top)+myStrog.speed+"px";
        if (parseInt(myStrog.imgNode.style.top)>=555){
            myStrog.imgNode.style.top="555px";
        }
    }
//    左
    if(moveLeft){
       /* if(!haveBullet) {
            myStrog.imgNode.src = "images/dragon/small/move.gif";
        }*/
        myStrog.imgNode.style.left=parseInt(myStrog.imgNode.style.left)-myStrog.speed+"px";
        if (parseInt(myStrog.imgNode.style.left)<=0){
            myStrog.imgNode.style.left="0px";
        }
    }
//    右
    if(moveRight){
        myStrog.imgNode.style.left=parseInt(myStrog.imgNode.style.left)+myStrog.speed+"px";
        if (parseInt(myStrog.imgNode.style.left)>=950){
            myStrog.imgNode.style.left="950px";
        }
    }
    strogLifeNode.style.left=parseInt(myStrog.imgNode.style.left)+5+"px";
    strogLifeNode.style.top=parseInt(myStrog.imgNode.style.top)-20+"px";
}
//吐子弹
function attBullet() {
    //    吐子弹
    if(haveBullet){
        //实例化一个子弹对象
        // myStrog.imgNode.src="images/dragon/small/magicmissile.gif";
        if(myStrog.lv==1){
            var bullet=new Bullter("images/dragon/small/att.gif");
        }
        if(myStrog.lv==2){
            var bullet=new Bullter("images/dragon/middle/att.gif");
        }
        if(myStrog.lv==3){
            var bullet=new Bullter("images/dragon/large/att.gif");
        }
        if(myStrog.lv==4){
            var bullet=new Bullter("images/dragon/final/att.gif");
        }
        bullet.imgNode.style.left=parseInt(myStrog.imgNode.style.left)+57+"px";
        bullet.imgNode.style.top=parseInt(myStrog.imgNode.style.top)+27+"px";
        //    讲子弹对象存放到子弹数组中
        BulletArray.push(bullet);
    }
}
//BOSS
function BOSS() {
    this.bossPosX=700;
    this.bossPosY=200;
    this.imgNode=document.createElement("img");
    this.speed=100;
    this.isHit=false;
    this.leaveTime=10;
    this.life=4000;
//    初始化boss
    this.initBoss=function () {
        this.imgNode.src="images/enemy/boss/move.gif";
        this.imgNode.style.left=this.bossPosX+"px";
        this.imgNode.style.top=this.bossPosY+"px";
        bg.appendChild(this.imgNode);
    }
    this.initBoss();
}
//子弹自动移动
function BullterAutoMove() {
    // console.log(BulletArray.length)
    for (var i=0;i<BulletArray.length;i++){
        var Bulletx=parseInt(BulletArray[i].imgNode.style.left)+parseInt(BulletArray[i].imgNode.offsetWidth);
        var Bullety=parseInt(BulletArray[i].imgNode.style.top)+parseInt(BulletArray[i].imgNode.offsetHeight);
        for (var z=0;z<BadBirdAraay.length;z++){
            var BadBirdx=parseInt(BadBirdAraay[z].imgNode.style.left);
            var BadBirdy=parseInt(BadBirdAraay[z].imgNode.style.top);
            if((Bulletx>=BadBirdx)&&(Bulletx<=(BadBirdx+parseInt(BadBirdAraay[z].imgNode.offsetWidth)))){
                if((Bullety>=BadBirdy)&&(Bullety<=(BadBirdy+parseInt(BadBirdAraay[z].imgNode.offsetHeight)))){
                    BulletArray[i].isHit=true;
                }
            }
        }
        if(boss!=null){
            // console.log("执行了");
            if (Bulletx>=parseInt(boss.imgNode.style.left)&&Bulletx<=(parseInt(boss.imgNode.style.left)+parseInt(boss.imgNode.offsetWidth))){
                if (Bullety>=parseInt(boss.imgNode.style.top)&&Bullety<=(parseInt(boss.imgNode.style.top)+parseInt(boss.imgNode.offsetHeight))){
                    BulletArray[i].isHit=true;
                    boss.isHit=true;
                    boss.imgNode.src="images/enemy/boss/hit.gif";
                    if (myStrog.lv==1){
                        boss.life=boss.life-10;
                        console.log(boss.life);
                    }
                    if (myStrog.lv==2){
                        boss.life=boss.life-40;
                        console.log(boss.life);
                    }
                    if (myStrog.lv==3){
                        boss.life=boss.life-80;
                        console.log(boss.life);
                    }
                    if (myStrog.lv==4){
                        boss.life=boss.life-100;
                        console.log(boss.life);
                    }
                    if(boss.life>0){
                        boss.isHit=false;
                        boss.imgNode.src="images/enemy/boss/move.gif";
                    }
                    if (boss.life<=0){
                        console.log("game over");
                        Playerscore=Playerscore+1000;
                        scoreNumNode.innerHTML=Playerscore;
                        gameover();
                    }
                }
            }
        }
       if(!BulletArray[i].isHit){
           BulletArray[i].BullterMove();
           if(parseInt(BulletArray[i].imgNode.style.left)>=1000){
               bg.removeChild(BulletArray[i].imgNode);
               BulletArray.splice(i,1);
           }
       }
       else {
           if (myStrog.lv==1){
               BulletArray[i].imgNode.src="images/dragon/small/hit.gif";
           }
           if (myStrog.lv==2){
               BulletArray[i].imgNode.src="images/dragon/middle/hit.gif";
           }
           if (myStrog.lv==3){
               BulletArray[i].imgNode.src="images/dragon/large/hit.gif";
           }
           if (myStrog.lv==4){
               BulletArray[i].imgNode.src="images/dragon/final/hit.gif";
           }
           BulletArray[i].leaveTime--;
           if(BulletArray[i].leaveTime<=0){
               bg.removeChild(BulletArray[i].imgNode);
               BulletArray.splice(i,1);
           }
       }
    }
}
//敌方飞机对象
function BadBird(imgSrc,speed,BadName) {
//    敌机位置
    this.posBirX=1000;
    this.posBirY=Math.random()*550;
    this.imgNode=document.createElement("img");
//    敌机src
    this.imgSrc=imgSrc;
//    敌机移动速度
    this.speed=speed;
    //敌机类型
    this.BadBidName=BadName;
//    是否被击中
    this.isHit=false;
//    消失时间
    this.leaveTime=10;
//    血量
    this.life=100;
//    初始化位置
    this.initBirPos=function () {
        this.imgNode.src=this.imgSrc;
        this.imgNode.style.left=this.posBirX+"px";
        this.imgNode.style.top=this.posBirY+"px";
        bg.appendChild(this.imgNode);
    }
    this.initBirPos();
//    敌机移动方法
    this.badBirMove=function () {
        this.imgNode.style.left=parseInt(this.imgNode.style.left)-this.speed+"px";
    }
}
//实例化敌机对象
function createBadBird1() {
    var imgsrc="images/enemy/bird/move.gif";
    var badBird=new BadBird(imgsrc,15,1);
    BadBirdAraay.push(badBird);

}
function createBadBird2() {
    var imgsrc="images/enemy/ghost/move.gif";
    var badBird=new BadBird(imgsrc,15,2);
    BadBirdAraay.push(badBird);
}
function createBadBird3() {
    var imgsrc="images/enemy/plane/move.gif";
    var badBird=new BadBird(imgsrc,15,3);
    BadBirdAraay.push(badBird);
    // console.log(BadBirdAraay.length);
}
//敌机生成
function createBadBird() {
    var BadNum=(Math.random()*10);
    if(BadNum<=4){
        createBadBird1();
    }else if(BadNum<=7){
        createBadBird2();
    }else if(BadNum<=10){
        createBadBird3();
    }
}
//敌机移动
function BadBirdMove() {
    // console.log(BulletArray.length);
    for (var i=0;i<BadBirdAraay.length;i++){
        var BadBirdx=parseInt(BadBirdAraay[i].imgNode.style.left);
        var BadBirdy=parseInt(BadBirdAraay[i].imgNode.style.top);
        for (var z=0;z<BulletArray.length;z++){
            var Bulletx=parseInt(BulletArray[z].imgNode.style.left);
            var Bullety=parseInt(BulletArray[z].imgNode.style.top);
            if((Bulletx+parseInt(BulletArray[z].imgNode.offsetWidth)>=BadBirdx)&&(Bulletx<=(BadBirdx+parseInt(BadBirdAraay[i].imgNode.offsetWidth)))){
                if((Bullety+parseInt(BulletArray[z].imgNode.offsetHeight)>=BadBirdy)&&(Bullety<=(BadBirdy+parseInt(BadBirdAraay[i].imgNode.offsetHeight)))){
                    BadBirdAraay[i].isHit=true;
                }
            }
        }
       if (!BadBirdAraay[i].isHit){
           BadBirdAraay[i].imgNode.style.left=parseInt(BadBirdAraay[i].imgNode.style.left)-BadBirdAraay[i].speed+"px";
           // console.log(BadBirdAraay[i].imgNode.style.left);
           if(parseInt(BadBirdAraay[i].imgNode.style.left)<=0){
               bg.removeChild(BadBirdAraay[i].imgNode);
               BadBirdAraay.splice(i,1);
           }
       }else {
           //打到飞机1
           if (BadBirdAraay[i].BadBidName==1){
               BadBirdAraay[i].imgNode.src="images/enemy/bird/die.gif";
               if(myStrog.lv==1){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-15;
               }
               if(myStrog.lv==2){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-20;
               }
               if(myStrog.lv==3){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-30;
               }
               if(myStrog.lv==4){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-40;
               }
               if(BadBirdAraay[i].life>=0){
                   // console.log(BadBirdAraay[i].life);
                   BadBirdAraay[i].imgNode.style.left=parseInt(BadBirdAraay[i].imgNode.style.left)-BadBirdAraay[i].speed+"px";
                   BadBirdAraay[i].imgNode.src="images/enemy/bird/move.gif";
                   BadBirdAraay[i].isHit=false;
               }
               else {
                   BadBirdAraay[i].leaveTime--;
                   if(BadBirdAraay[i].leaveTime<=0){
                       bg.removeChild(BadBirdAraay[i].imgNode);
                       BadBirdAraay.splice(i,1);
                       Playerscore=Playerscore+1;
                       exp=exp+20;
                       scoreNumNode.innerHTML=Playerscore;
                   }
               }
           }
           //打到飞机2
           if (BadBirdAraay[i].BadBidName==2){
               BadBirdAraay[i].imgNode.src="images/enemy/ghost/die.gif";
               if(myStrog.lv==1){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-10;
               }
               if(myStrog.lv==2){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-15;
               }
               if(myStrog.lv==3){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-20;
               }
               if(myStrog.lv==4){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-30;
               }
               if(BadBirdAraay[i].life>=0){
                   // console.log(BadBirdAraay[i].life);
                   BadBirdAraay[i].imgNode.style.left=parseInt(BadBirdAraay[i].imgNode.style.left)-BadBirdAraay[i].speed+"px";
                   BadBirdAraay[i].imgNode.src="images/enemy/ghost/move.gif";
                   BadBirdAraay[i].isHit=false;
               }
               else {
                   BadBirdAraay[i].leaveTime--;
                   if(BadBirdAraay[i].leaveTime<=0){
                       bg.removeChild(BadBirdAraay[i].imgNode)
                       BadBirdAraay.splice(i,1);
                       Playerscore=Playerscore+2;
                       exp=exp+30;
                       scoreNumNode.innerHTML=Playerscore;
                   }
               }
           }
           //打到飞机3
           if (BadBirdAraay[i].BadBidName==3){
               BadBirdAraay[i].imgNode.src="images/enemy/plane/die.gif";
               if(myStrog.lv==1){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-5;
               }
               if(myStrog.lv==2){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-10;
               }
               if(myStrog.lv==3){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-15;
               }
               if(myStrog.lv==4){
                   BadBirdAraay[i].life=BadBirdAraay[i].life-30;
               }
               // console.log(BadBirdAraay[i].life);
               if(BadBirdAraay[i].life>=0){
                    console.log(BadBirdAraay[i].life);
                   BadBirdAraay[i].imgNode.style.left=parseInt(BadBirdAraay[i].imgNode.style.left)-BadBirdAraay[i].speed+"px";
                   BadBirdAraay[i].imgNode.src="images/enemy/plane/move.gif";
                   BadBirdAraay[i].isHit=false;
               }
               else {
                   BadBirdAraay[i].leaveTime--;
                   if(BadBirdAraay[i].leaveTime<=0){
                       bg.removeChild(BadBirdAraay[i].imgNode)
                       BadBirdAraay.splice(i,1);
                       //    实例化宝箱对象
                       var chest=new Chest(BadBirdx,BadBirdy);
                       ChestArray.push(chest);
                       Playerscore=Playerscore+3;
                       exp=exp+40;
                       scoreNumNode.innerHTML=Playerscore;
                   }
               }
           }
       }
    }
}
//宝箱对象
function Chest(x,y) {
    //创建节点
    this.imgNode=document.createElement("img");
    this.posChestX=x;
    this.posChestY=y;
//    消失时间
    this.leaveTime=100;
//    初始化宝箱位置
    this.initChest=function () {
        this.imgNode.src="images/enemy/thing.gif";
        bg.appendChild(this.imgNode);
        this.imgNode.style.left=this.posChestX+"px";
        this.imgNode.style.top=this.posChestY+"px";
    }
    this.initChest();
}
//宝箱消失
function chestLeave() {
    for(var i=0;i<ChestArray.length;i++){
        var chestX=parseInt(ChestArray[i].imgNode.style.left);
        var chestY=parseInt(ChestArray[i].imgNode.style.top);
        var myStrogX=parseInt(myStrog.imgNode.style.left);
        var myStrogY=parseInt(myStrog.imgNode.style.top);
        if (myStrogY+parseInt(myStrog.imgNode.offsetHeight)>=chestY&&myStrogY<=(chestY+parseInt(ChestArray[i].imgNode.offsetHeight))){
            if (myStrogX+parseInt(myStrog.imgNode.offsetWidth)>=chestX&&myStrogX<=(chestX+parseInt(ChestArray[i].imgNode.offsetWidth))){
                bg.removeChild(ChestArray[i].imgNode);
                ChestArray.splice(i,1);
                ChestCount++;
                if (ChestCount>=7){
                    ChestCount=7;
                }
            }
        }else {
            ChestArray[i].leaveTime--;
            if(ChestArray[i].leaveTime<=0){
                bg.removeChild(ChestArray[i].imgNode);
                ChestArray.splice(i,1);
            }
        }
    }
}
//飞机成长
function expGrow() {
    if(myStrog.lv<4){
        expNode.style.height=parseInt(expNode.offsetHeight)+exp+"px";
        exp=0;
        if(parseInt(expNode.style.height)>=166){
            console.log(myStrog.lv);
            myStrog.lv=myStrog.lv+1;
            expNode.style.height=50+"px";
        }
    }else {
        expNode.style.height=50+"px";
    }
}
//改变Boom数量
function changeBoom() {
    switch (ChestCount){
        case 0:
            boomNode.src="images/ui/boom/boom0.png";break;
        case 1:
            boomNode.src="images/ui/boom/boom1.png";break;
        case 2:
            boomNode.src="images/ui/boom/boom2.png";break;
        case 3:
            boomNode.src="images/ui/boom/boom3.png";break;
        case 4:
            boomNode.src="images/ui/boom/boom4.png";break;
        case 5:
            boomNode.src="images/ui/boom/boom5.png";break;
        case 6:
            boomNode.src="images/ui/boom/boom6.png";break;
        case 7:
            boomNode.src="images/ui/boom/boom7.png";break;
    }
}
function bossMove() {
    if(Math.random()*2<=1){
        boss.imgNode.style.top=parseInt(boss.imgNode.style.top)+boss.speed+"px";
        if(parseInt(boss.imgNode.style.top)>=400){
            boss.imgNode.style.top=400+"px";
        }
    }
    else {
        boss.imgNode.style.top=parseInt(boss.imgNode.style.top)-boss.speed+"px";
        if(parseInt(boss.imgNode.style.top)<=-30){
            boss.imgNode.style.top=-30+"px";
        }
    }
}
//时间改变
function timeChange() {
    // console.log(sec2);
    if(sec2==0){
        sec2=10;
    }
    sec2--;
    switch (sec2){
        case 0:sec2Node.src="images/num/0.gif";break;
        case 1:sec2Node.src="images/num/1.gif";break;
        case 2:sec2Node.src="images/num/2.gif";break;
        case 3:sec2Node.src="images/num/3.gif";break;
        case 4:sec2Node.src="images/num/4.gif";break;
        case 5:sec2Node.src="images/num/5.gif";break;
        case 6:sec2Node.src="images/num/6.gif";break;
        case 7:sec2Node.src="images/num/7.gif";break;
        case 8:sec2Node.src="images/num/8.gif";break;
        case 9:sec2Node.src="images/num/9.gif";break;
        case 10:sec2Node.src="images/num/0.gif";break;
    }
    if (sec2==9){
        sec1--;
    }
    if(sec1<=0){
        min2--;
        xxxx--;
        if(xxxx<=-1){
            sec1=0;
        }else {
            sec1=5;
        }
    }
    switch (sec1){
        case 0:sec1Node.src="images/num/0.gif";break;
        case 1:sec1Node.src="images/num/1.gif";break;
        case 2:sec1Node.src="images/num/2.gif";break;
        case 3:sec1Node.src="images/num/3.gif";break;
        case 4:sec1Node.src="images/num/4.gif";break;
        case 5:sec1Node.src="images/num/5.gif";break;
        // case 6:sec1Node.src="images/num/6.gif";break;
    }
    switch (min2){
        case 0:min2Node.src="images/num/0.gif";break;
        case 1:min2Node.src="images/num/1.gif";break;
    }
    // console.log(TimeChangeTime);
}
//boss发子弹
function bossAtck() {
    bossatckTime++;
    if (bossatckTime==4){
        boss.imgNode.src="images/enemy/boss/attack.gif";
        var bossBullet=new Bullter("images/enemy/boss/attackBall.gif");
        bossBullet.imgNode.style.top=parseInt(boss.imgNode.style.top)+parseInt(boss.imgNode.offsetHeight)/2+"px";
        bossBullet.imgNode.style.left=parseInt(boss.imgNode.style.left)-50+"px";
        bossBulletArray.push(bossBullet);
        bossatckTime=0;
    }
}
//boss子弹移动
function bossBulletMove() {
    for (var i=0;i<bossBulletArray.length;i++){
        bossBulletArray[i].imgNode.style.left=parseInt(bossBulletArray[i].imgNode.style.left)-bossBulletArray[i].speed+"px";
        var myStrogX=parseInt(myStrog.imgNode.style.left);
        var myStrogY=parseInt(myStrog.imgNode.style.top);
        var bossBulletX=parseInt(bossBulletArray[i].imgNode.style.left);
        var bossBulletY=parseInt(bossBulletArray[i].imgNode.style.top);
        if(myStrogX+parseInt(myStrog.imgNode.offsetWidth)>=bossBulletX&&(myStrogX<=bossBulletX+parseInt(bossBulletArray[i].imgNode.offsetWidth))){
            if(myStrogY+parseInt(myStrog.imgNode.offsetHeight)>=bossBulletY&&(myStrogY<=bossBulletY+parseInt(bossBulletArray[i].imgNode.offsetHeight))){
                myStrog.life=myStrog.life-10;
                xuetiaoNode.style.width=myStrog.life+"px";
                xuetiaoNode.style.height=7+"px";
                if(myStrog.life<=0){
                    xuetiaoNode.style.width=0+"px";
                    gameover();
                }
            }
        }
    }
}
//放大招
function fangdazhao() {
    if(isdazhao&&ChestCount>=1){
        skillNode.src="images/skill.gif";
        skilltime=10;
        cunzaidazhao=1;
        ChestCount--;
    }
    skilltime--;
    if(skilltime==2&&cunzaidazhao==1&&gameing){
        for (var i=0;i<BadBirdAraay.length;i++){
            BadBirdAraay[i].isHit=true;
            BadBirdAraay[i].life=0;
        }
        if(boss!=null){
            boss.isHit=true;
            boss.life=boss.life-300;
            console.log(boss.life);
        }
    }
    if(skilltime<=0){
        skillNode.src="";
        cunzaidazhao=0;
        isdazhao=false;
    }
}
function gameover() {
    clearInterval(MyStrogMoveTime);
    clearInterval(attBulletTime);
    clearInterval(BullterMoveTime);
    clearInterval(BadBirdTime);
    clearInterval(BadBirdMoveTime);
    clearInterval(ChestLeaveTime);
    clearInterval(expGrowTime);
    clearInterval(changeBoomTime);
    clearInterval(TimeChangeTime);
    clearInterval(GameOverTime);
    clearInterval(bossMoveTime);
    clearInterval(bossAtckTime);
    clearInterval(bossBulletMoveTime);
    jifenbanNode.style.opacity="1";
    finalfenshu.innerHTML=Playerscore;
    chongwan.style.opacity="1";
    chongwan.style.zIndex=999;
    gameing=false;
}
function restartGame() {
    window.location.reload();
}
//实例化主角对象
var myStrog=new Strog(5);
//监听按下键盘
document.addEventListener("keydown",function (e) {
    if (!e) {
        e = window.event;
    }
    if (e.keyCode==32){
        haveBullet=true;
       if(myStrog.lv==1){
           myStrog.imgNode.src="images/dragon/small/magicmissile.gif";
       }
       if(myStrog.lv==2){
           myStrog.imgNode.src="images/dragon/middle/magicmissile.gif";
       }
        if(myStrog.lv==3){
            myStrog.imgNode.src="images/dragon/large/magicmissile.gif";
        }
        if(myStrog.lv==4){
            myStrog.imgNode.src="images/dragon/final/magicmissile.gif";
        }
    }
    if (e.keyCode == 38) {
        moveUp = true;
        if(!haveBullet) {
            if(myStrog.lv==1){
                myStrog.imgNode.src="images/dragon/small/move.gif";
            }
            if(myStrog.lv==2){
                myStrog.imgNode.src="images/dragon/middle/move.gif";
            }
            if(myStrog.lv==3){
                myStrog.imgNode.src="images/dragon/large/move.gif";
            }
            if(myStrog.lv==4){
                myStrog.imgNode.src="images/dragon/final/move.gif";
            }
        }
    }
    if (e.keyCode == 37) {
        moveLeft = true;
        if(!haveBullet) {
            if(myStrog.lv==1){
                myStrog.imgNode.src="images/dragon/small/move.gif";
            }
            if(myStrog.lv==2){
                myStrog.imgNode.src="images/dragon/middle/move.gif";
            }
            if(myStrog.lv==3){
                myStrog.imgNode.src="images/dragon/large/move.gif";
            }
            if(myStrog.lv==4){
                myStrog.imgNode.src="images/dragon/final/move.gif";
            }
        }
    }
    if (e.keyCode == 39) {
        moveRight = true;
        if(!haveBullet) {
            if(myStrog.lv==1){
                myStrog.imgNode.src="images/dragon/small/move.gif";
            }
            if(myStrog.lv==2){
                myStrog.imgNode.src="images/dragon/middle/move.gif";
            }
            if(myStrog.lv==3){
                myStrog.imgNode.src="images/dragon/large/move.gif";
            }
            if(myStrog.lv==4){
                myStrog.imgNode.src="images/dragon/final/move.gif";
            }
        }
    }
    if (e.keyCode == 40) {
        moveDown = true;
        if(!haveBullet) {
            if(myStrog.lv==1){
                myStrog.imgNode.src="images/dragon/small/move.gif";
            }
            if(myStrog.lv==2){
                myStrog.imgNode.src="images/dragon/middle/move.gif";
            }
            if(myStrog.lv==3){
                myStrog.imgNode.src="images/dragon/large/move.gif";
            }
            if(myStrog.lv==4){
                myStrog.imgNode.src="images/dragon/final/move.gif";
            }
        }
    }
    if (e.keyCode==13){
        isdazhao=true;
    }
});
// 监听离开键盘
document.addEventListener("keyup",function (e) {
    if (!e) {
        e = window.event;
    }
    if (e.keyCode==13){
        isdazhao=false;
    }
    if (e.keyCode == 38) {
        moveUp = false;
        if(!haveBullet) {
            if(myStrog==1){
                myStrog.imgNode.src="images/dragon/small/stand.gif";
            }
            if(myStrog==2){
                myStrog.imgNode.src="images/dragon/middle/stand.gif";
            }
            if(myStrog==3){
                myStrog.imgNode.src="images/dragon/large/stand.gif";
            }
            if(myStrog==4){
                myStrog.imgNode.src="images/dragon/final/stand.gif";
            }
        }
    }
    if (e.keyCode == 37) {
        moveLeft = false;
        if(!haveBullet) {
            if(myStrog==1){
                myStrog.imgNode.src="images/dragon/small/stand.gif";
            }
            if(myStrog==2){
                myStrog.imgNode.src="images/dragon/middle/stand.gif";
            }
            if(myStrog==3){
                myStrog.imgNode.src="images/dragon/large/stand.gif";
            }
            if(myStrog==4){
                myStrog.imgNode.src="images/dragon/final/stand.gif";
            }
        }
    }
    if (e.keyCode == 39) {
        moveRight = false;
        if(!haveBullet) {
            if(myStrog==1){
                myStrog.imgNode.src="images/dragon/small/stand.gif";
            }
            if(myStrog==2){
                myStrog.imgNode.src="images/dragon/middle/stand.gif";
            }
            if(myStrog==3){
                myStrog.imgNode.src="images/dragon/large/stand.gif";
            }
            if(myStrog==4){
                myStrog.imgNode.src="images/dragon/final/stand.gif";
            }
        }
    }
    if (e.keyCode == 40) {
        moveDown = false;
        if(!haveBullet) {
            if(myStrog==1){
                myStrog.imgNode.src="images/dragon/small/stand.gif";
            }
            if(myStrog==2){
                myStrog.imgNode.src="images/dragon/middle/stand.gif";
            }
            if(myStrog==3){
                myStrog.imgNode.src="images/dragon/large/stand.gif";
            }
            if(myStrog==4){
                myStrog.imgNode.src="images/dragon/final/stand.gif";
            }
        }
    }
    if (e.keyCode==32){
        haveBullet=false;
        if(myStrog.lv==1){
            myStrog.imgNode.src="images/dragon/small/stand.gif";
        }
        if(myStrog.lv==2){
            myStrog.imgNode.src="images/dragon/middle/stand.gif";
        }
        if(myStrog.lv==3){
            myStrog.imgNode.src="images/dragon/large/stand.gif";
        }
        if(myStrog.lv==4){
            myStrog.imgNode.src="images/dragon/final/stand.gif";
        }
    }
});
chongwan.addEventListener("click",restartGame,false);
function begainGame() {
    // 移动
     MyStrogMoveTime=setInterval(myStrogMove,40);
//吐子弹
    attBulletTime=setInterval(attBullet,700);
//子弹自动移动
    BullterMoveTime=setInterval(BullterAutoMove,100);
//创建敌机
    BadBirdTime=setInterval(createBadBird,2500);
//敌机移动
    BadBirdMoveTime=setInterval(BadBirdMove,100);
//吃宝箱
    ChestLeaveTime=setInterval(chestLeave,100);
    expGrowTime=setInterval(expGrow,1000);
//changeBoom
    changeBoomTime=setInterval(changeBoom,10);
//计数时间
    TimeChangeTime=setInterval(timeChange,1000);
//游戏结束时间
    GameOverTime=setInterval(function (e) {
        time++;
        // console.log(time);
        if (time==50){
            boss=new BOSS();
            clearInterval(BadBirdTime);
            bossMoveTime=setInterval(bossMove,500);
            bossAtckTime=setInterval(bossAtck,1000);
            bossBulletMoveTime=setInterval(bossBulletMove,500);
        }
        if (time>=91){
            clearInterval(TimeChangeTime);
            clearInterval(GameOverTime);
            gameover();
        }
    },1000);
//大招时间
    fangdazhaoTime=setInterval(fangdazhao,350);
};
window.onload=function () {
    gameStartNode.addEventListener('click',function (e) {
        baginWarpNode.style.opacity="0";
        baginWarpNode.style.zIndex=-1;
        begainGame();
    });
}
